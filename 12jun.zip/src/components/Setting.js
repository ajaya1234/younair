import React from "react";
import Sidebar from "./Sidebar";
import Header from "./Header";
import { MdDescription, MdOutlineRotate90DegreesCw } from "react-icons/md";
import { Link } from "react-router-dom";
import { AiOutlineCamera } from "react-icons/ai";
import { AiOutlineCopy } from "react-icons/ai";
import { AiOutlineEdit } from "react-icons/ai";
import Switch from "@mui/material/Switch";
import "../setting.css";
import { useState } from "react";
import axios from "axios";
import { useEffect } from "react";

const Setting = () => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [description, setDescription] = useState(null);  
  const [ channelname , setChannelname ] = useState('');
  const [lists, setLists] = useState([]);


  const usered = localStorage.getItem("_id");

  const handleImageSelect = (event) => {
    setSelectedImage(event.target.files[0]);
  };

  const handleFormSubmit = async (event) => {
    event.preventDefault();
    const formData = new FormData();
    formData.append("profile_image", selectedImage);
    formData.append("cover_image", selectedImage);
    formData.append("user_id", usered);
    formData.append("channel_name", channelname);
    formData.append("handle", description);


    try {
      const response = await axios.post(
        "http://16.16.91.234:3003/api/create_channel",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
    } catch (error) {
      console.error("Error updating profile picture:", error.response.data);
    }
  };

  useEffect(() => {
    getHomeData2();
  }, []);

  const getHomeData2 = async () => {
    const userid = localStorage.getItem("_id");

    const options = {
      headers: {
        "content-type": "application/json; charset=utf-8",
        "Access-Control-Allow-Origin": "*",
      },
    };

    const data = {
      user_id: userid,
    };

    try {
      const response = await axios.post(
        "http://16.16.91.234:3003/api/get_my_channel",
        data,
        options
      );
      if (response.data.data && response.data.data.length > 0) {
        setLists(response.data.data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const label = { inputProps: { "aria-label": "Switch demo" } };
  return (
    <>
      <Header />
      <Sidebar />
      <div id="wrapper">
        <div id="content-wrapper">
          <div className="container-fluid">
            <div className="video-block section-padding">
              <div className="row">
                <div className="col-md-12">
                  <div className="main-title">
                    <h6>Setting</h6>
                  </div>
                </div>
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div
                    className="category-item mt-0 mb-0"
                    style={{ background: "#fafafa" }}
                  >
                    <a data-toggle="modal" data-target="#myModal" href>
                      <img className="img-fluid" src="img/profile.png" alt="" />
                      <h5 data-toggle="modal" data-target="#myModal">
                        Profile Settings{" "}
                        <span
                          data-toggle="modal"
                          data-target="#myModal"
                          title
                          data-placement="top"
                          data-original-title="Verified"
                        />
                      </h5>
                    </a>
                    
                  </div>
                </div>
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div
                    className="category-item mt-0 mb-0"
                    style={{ background: "#fafafa" }}
                  >
                    <a href>
                      <img className="img-fluid" src="img/data.png" alt="" />
                      <h5>
                        data Saving
                        <span
                          title
                          data-placement="top"
                          data-toggle="tooltip"
                          data-original-title="Verified"
                        />
                      </h5>
                    </a>
                  </div>
                </div>
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div
                    className="category-item mt-0 mb-0"
                    style={{ background: "#fafafa" }}
                  >
                    <Link to="/myvideo">
                      <img
                        className="img-fluid"
                        src="img/Download.png"
                        alt=""
                      />
                      <h5>Download</h5>
                    </Link>
                  </div>
                </div>
                
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div
                    className="category-item mt-0 mb-0"
                    style={{ background: "#fafafa" }}
                  >
                    <a href>
                      <img className="img-fluid" src="img/Chat.png" alt="" />
                      <h5>Chat</h5>
                    </a>
                  </div>
                </div>
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div
                    className="category-item mt-0 mb-0"
                    style={{ background: "#fafafa" }}
                  >
                    <Link to="/notification">
                      <img
                        className="img-fluid"
                        src="img/notification.jpg"
                        alt=""
                      />
                      <h5>Notification</h5>
                    </Link>
                  </div>
                </div>
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div
                    className="category-item mt-0 mb-0"
                    style={{ background: "#fafafa" }}
                  >
                    <Link to="/refer">
                      <MdOutlineRotate90DegreesCw
                        style={{ color: "black", fontSize: "45px" }}
                      />
                      <h5>Refer And Earn</h5>
                    </Link>
                  </div>
                </div>
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div
                    className="category-item mt-0 mb-0"
                    style={{ background: "#fafafa" }}
                  >
                    <Link to="/about">
                      <img className="img-fluid" src="img/see.png" alt="" />
                      <h5>About</h5>
                    </Link>
                  </div>
                </div>

                <div className="col-xl-3 col-sm-3 mb-3">
                  <div
                    className="category-item mt-0 mb-0"
                    style={{ background: "#fafafa" }}
                  >
                    <Link to="/changepassword">
                      <img className="img-fluid" src="img/see.png" alt="" />
                      <h5>Change Password</h5>
                    </Link>
                  </div>
                </div>


                
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div
                    className="category-item mt-0 mb-0"
                    style={{ background: "#fafafa" }}
                  >
                    <Link to="/changeprofile">
                      <img className="img-fluid" src="img/see.png" alt="" />
                      <h5>Change Profile Picture</h5>
                    </Link>
                  </div>
                </div>
              
              
              





              
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="modal" id="myModal">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h4 className="modal-title">Your Profile</h4>
              <button type="button" className="close" data-dismiss="modal">
                ×
              </button>
            </div>
            {/* {lists.map((list) => {
                          return (
            <div className="modal-body">
              <div className="single-channel-image">
               
                <img style={{height:'100px'}}
                  className="img-fluid"
                  alt
                  src={
                    "http://16.16.91.234:3003/uploads/" +
                    list.image[0].filename
                  }
                /> */}


{lists.length > 0 && lists[0].image && lists[0].image[0].filename ? (
  <div className="modal-body">
    <div className="single-channel-image">
      <img
        style={{ height: '250px' }}
        className="img-fluid"
        alt="Channel Image"
        src={"http://16.16.91.234:3003/uploads/" + lists[0].image[0].filename}
      />
    </div>
  </div>
) : (
  <div className="modal-body">
    <div className="single-channel-image">
      <img
        style={{ height: '250px' }}
        className="img-fluid"
        alt="Channel Image"
        src="img/logo.png" // Replace with your default image URL
      />
    </div>
  </div>
)}




<div className="channel-profile">
  {lists.length > 0 && lists[0].image && lists[0].image[1].filename ? (
    <img
      className="channel-profile-img"
      alt=""
      src={"http://16.16.91.234:3003/uploads/" + lists[0].image[1].filename}
    />
  ) : (
    <img
      className="channel-profile-img"
      alt=""
      src="img/logo.png" 
    />
  )}
  <div className="social hidden-xs">
    <a href="settings.html">
      <i
        style={{ fontSize: 35, color: "white" }}
        className="fa fa-gear"
      />
    </a>
    <a href>
      <i
        style={{ fontSize: 35, color: "white" }}
        className="fa fa-edit"
      />
    </a>
  </div>
</div>

              </div>
              <a
                style={{ marginLeft: "15px" }}
                className="channel-brand"
                href="#"
              >
                Osahan Channel{" "}
                <span
                  title
                  data-placement="top"
                  data-toggle="tooltip"
                  data-original-title="Verified"
                >
                  <i className="fas fa-check-circle text-success" />
                </span>
              </a>
              <h6 className="pl-3" style={{ fontSize: "12px" }}>
                dhananjay@gmail.com
              </h6>
            </div>
            
            <div>             &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <label  htmlFor="profile-picture-input">
                <span className="btn btn-info">
                Profile picture</span>
                <input
                  id="profile-picture-input"
                  type="file"
                  onChange={handleImageSelect}
                  style={{ display: "none" }}
                />
              </label>
              <br/>
             &nbsp;&nbsp;&nbsp;&nbsp; <label htmlFor="profile-picture-input">
             <span className="btn btn-info">
             Cover Image</span>
                
                <input 
                  id="profile-picture-input"
                  type="file"
                  onChange={handleImageSelect}
                  style={{ display: "none" }}
                />
              </label>
              {/* <form onSubmit={handleFormSubmit}>
              &nbsp;&nbsp;&nbsp;&nbsp; <button
                  onClick={getHomeData2}
                  className="btn btn-info"
                  type="submit"
                >
                  Updated
                </button>
                
                
              </form> */}
            
            </div>
            
            <div className="card-footer">
              <form className="mb-3">
                <div class="form-group">
                  <label for="email">Channel_Name:</label>
                  <input
                    type="text"
                    value={channelname} onChange={(e)=>setChannelname(e.target.value)}
                    class="form-control  profile1"
                  />
                </div>
                
                <div class="form-group">
                  <label for="pwd">Description:</label>
                  <input
                    type="text"
                    value={description} onChange={(e)=>setDescription(e.target.value)}
                    class="form-control  profile2"
                  />
                </div>
               
               
              

                <button onSubmit={handleFormSubmit} className="btn btn-info" type="submit">
                  submit
                </button>
              </form>
              <h6>Privacy</h6>

              <div className="row">
                <h6
                  className="subscription"
                  style={{ marginLeft: "40px", fontSize: "13px" }}
                >
                  Keep all my subscription private
                </h6>
                <span className="subscriptionicon">
                  {" "}
                  <Switch
                    {...label}
                    defaultChecked
                    style={{ marginLeft: "" }}
                  />
                </span>
              </div>

              <div className="row">
                <h6
                  className="playlist"
                  style={{ marginLeft: "40px", fontSize: "13px" }}
                >
                  Keep all seved playlist private
                </h6>
                <span className="playlisticon">
                  {" "}
                  <Switch
                    {...label}
                    defaultChecked
                    style={{ marginLeft: "" }}
                  />
                </span>
              </div>

              <div></div>
            </div>
          </div>
       
     
    </>
  );
};

export default Setting;
