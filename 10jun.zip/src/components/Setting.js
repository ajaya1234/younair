import React from 'react'
import Sidebar from './Sidebar'
import Header from './Header'
import { MdOutlineRotate90DegreesCw } from 'react-icons/md'
import { Link } from 'react-router-dom'
import { AiOutlineCamera } from 'react-icons/ai'
import { AiOutlineCopy } from 'react-icons/ai'
import { AiOutlineEdit } from 'react-icons/ai'
import Switch from '@mui/material/Switch';
import '../setting.css'


const Setting = () => {
  const label = { inputProps: { 'aria-label': 'Switch demo' } };
  return (
    <>
      <Header />
      <Sidebar />
      <div id="wrapper">
        <div id="content-wrapper">
          <div className="container-fluid">
            <div className="video-block section-padding">
              <div className="row">
                <div className="col-md-12">
                  <div className="main-title">
                    <h6>Setting</h6>
                  </div>
                </div>
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div className="category-item mt-0 mb-0" style={{ background: '#fafafa' }}>
                    <a data-toggle="modal" data-target="#myModal" href>
                      <img className="img-fluid" src="img/profile.png" alt="" />
                      <h5 data-toggle="modal" data-target="#myModal">Profile Settings <span data-toggle="modal" data-target="#myModal" title data-placement="top" data-original-title="Verified" /></h5>
                    </a>
                    {/* <div class="ss"><img src="img/art.png" alt=""><h5>Art </h5> </div> */}
                  </div>
                </div>
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div className="category-item mt-0 mb-0" style={{ background: '#fafafa' }}>
                    <a href>
                      <img className="img-fluid" src="img/data.png" alt="" />
                      <h5>data Saving<span title data-placement="top" data-toggle="tooltip" data-original-title="Verified" /></h5>
                    </a>
                  </div>
                </div>
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div className="category-item mt-0 mb-0" style={{ background: '#fafafa' }}>
                    <Link to="/myvideo">
                      <img className="img-fluid" src="img/Download.png" alt="" />
                      <h5>Download</h5>
                    </Link>
                  </div>
                </div>
                {/* <div className="col-xl-3 col-sm-3 mb-3">
                  <div className="category-item mt-0 mb-0" style={{ background: '#fafafa' }}>
                    <a href>
                      <img className="img-fluid" src="img/tv.jpg" alt="" />
                      <h5>Watch on tv <span title data-placement="top" data-toggle="tooltip" data-original-title="Verified" /></h5>
                    </a>
                  </div>
                </div> */}
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div className="category-item mt-0 mb-0" style={{ background: '#fafafa' }}>
                    <a href>
                      <img className="img-fluid" src="img/Chat.png" alt="" />
                      <h5>Chat</h5>
                    </a>
                  </div>
                </div>
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div className="category-item mt-0 mb-0" style={{ background: '#fafafa' }}>
                    <Link to="/notification">
                      <img className="img-fluid" src="img/notification.jpg" alt="" />
                      <h5>Notification</h5>
                    </Link>
                  </div>
                </div>
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div className="category-item mt-0 mb-0" style={{ background: '#fafafa' }}>
                    <Link to="/refer">
                      <MdOutlineRotate90DegreesCw style={{ color: "black", fontSize: "45px" }} />
                      <h5>Refer And Earn</h5>
                    </Link>
                  </div>
                </div>
                <div className="col-xl-3 col-sm-3 mb-3">
                  <div className="category-item mt-0 mb-0" style={{ background: '#fafafa' }}>
                    <Link to="/about">
                      <img className="img-fluid" src="img/see.png" alt="" />
                      <h5>About</h5>
                    </Link>
                  </div>
                </div>

                <div className="col-xl-3 col-sm-3 mb-3">
                  <div className="category-item mt-0 mb-0" style={{ background: '#fafafa' }}>
                    <Link to='/changepassword'>
                      <img className="img-fluid" src="img/see.png" alt="" />
                      <h5>Change Password</h5>
                    </Link>
                  </div>
                </div>


              </div>

            </div>
          </div>

        </div>
      </div>

      <div className="modal" id="myModal">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h4 className="modal-title">Your Profile</h4>
              <button type="button" className="close" data-dismiss="modal">×</button>
            </div>
            <div className="modal-body">
              <div className="single-channel-image">
                <img className="img-fluid" alt src="img/channel-banner.png" />
                <div className="channel-profile">
                  <img className="channel-profile-img" alt src="img/s2.png" />
                  <div className="social hidden-xs">
                    <a href="settings.html">
                      <i style={{ fontSize: 35, color: 'white' }} className="fa fa-gear" /></a>
                    <a href>
                      <i style={{ fontSize: 35, color: 'white' }} className="fa fa-edit" /></a>
                  </div>

                </div>
              </div>
              <a style={{ marginLeft: "15px" }} className="channel-brand" href="#">Osahan Channel   <span title data-placement="top" data-toggle="tooltip" data-original-title="Verified"><i className="fas fa-check-circle text-success" /></span></a>
              <h6 className='pl-3' style={{ fontSize: "12px" }}>dhananjay@gmail.com</h6>
            </div>

            <div className='card-footer'>
              <form className='mb-3'>
                <div class="form-group">
                  <label for="email">Name:</label>
                  <input type="text" value={"anju"} class="form-control  profile1" />
                </div>
                <AiOutlineEdit className='icon1 ' style={{ fontSize: "20px", cursor: "pointer" }} />
                <div class="form-group">
                  <label for="pwd">Description:</label>
                  <input type="text" value={"description"} class="form-control  profile2" />
                </div>
                <AiOutlineEdit className='icon2' style={{ fontSize: "20px", cursor: "pointer" }} />
                <div class="form-group">
                  <label for="pwd">Channel Url:</label>
                  <input type="text" value={"http//sevenyoutube.com"} class="form-control urlname3" />
                </div>
                <AiOutlineCopy className='icon3' style={{ fontSize: "20px", cursor: "pointer" }} />

                <button className='btn btn-info' type='submit'>submit</button>
              </form>
              <h6>Privacy</h6>

              <div className='row'>
                <h6 className='subscription' style={{ marginLeft: "40px", fontSize: "13px" }}>Keep all my subscription private</h6>
                <span className='subscriptionicon'>    <Switch {...label} defaultChecked style={{ marginLeft: "" }} /></span>
              </div>


              <div className='row'>
                <h6 className='playlist' style={{ marginLeft: "40px", fontSize: "13px" }}>Keep all seved playlist private</h6>
                <span className='playlisticon'>    <Switch {...label} defaultChecked style={{ marginLeft: "" }} /></span>
              </div>

              <div>


              </div>
            </div>

          </div>
        </div>
      </div>

    </>
  )
}

export default Setting
