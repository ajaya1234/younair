import React from 'react'
import Sidebar from './Sidebar'
import Header from './Header'
import Footer from './Footer'

import '../setting.css'

const About = () => {
    return (
        <>
            <Header />
            <Sidebar />
            <div id="wrapper">
                <div id="content-wrapper">
                    <div className="container-fluid">
                        <div className="video-block section-padding">
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="main-title">
                                        <h6>Seven About</h6>
                                    </div>
                                    <h6>17 Tips for Writing Effective YouTube Descriptions (Free Template Included)

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers <br/>


                                        17 Tips for Writing Effective YouTube Descriptions (Free Template Included)

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers
                                        17 Tips for Writing Effective YouTube Descriptions (Free Template Included)

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers
                                        17 Tips for Writing Effective YouTube Descriptions (Free Template Included)<br/>

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers
                                        17 Tips for Writing Effective YouTube Descriptions (Free Template Included)<br/>

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers
                                        17 Tips for Writing Effective YouTube Descriptions (Free Template Included)<br/>

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers
                                        17 Tips for Writing Effective YouTube Descriptions (Free Template Included)<br/>

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers17 Tips for Writing Effective YouTube Descriptions (Free Template Included)

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers
                                        17 Tips for Writing Effective YouTube Descriptions (Free Template Included)<br/>

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers17 Tips for Writing Effective YouTube Descriptions (Free Template Included)

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers
                                        17 Tips for Writing Effective YouTube Descriptions (Free Template Included) <br/>

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers
                                        17 Tips for Writing Effective YouTube Descriptions (Free Template Included)<br/>

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers17 Tips for Writing Effective YouTube Descriptions (Free Template Included)

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers
                                        17 Tips for Writing Effective YouTube Descriptions (Free Template Included)<br/>

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers17 Tips for Writing Effective YouTube Descriptions (Free Template Included)

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers
                                        17 Tips for Writing Effective YouTube Descriptions (Free Template Included)<br/>

                                        Done right, YouTube descriptions can boost view counts and watch time. They can also help your videos rank in YouTube search.
                                        Greg Sides, Alice Fleerackers

                                    </h6>
                                </div>



                            </div>

                        </div>
                    </div>

                </div>
            </div>


            <Footer />
        </>
    )
}

export default About