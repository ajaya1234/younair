import React from 'react'
import { Link } from 'react-router-dom'

function Header() {
    return (
        <>
            <nav className="navbar navbar-expand navbar-light bg-dark static-top osahan-nav sticky-top" style={{zIndex:"1"}}>
                &nbsp;&nbsp;
                <button
                    className="btn btn-link btn-sm text-secondary order-1 order-sm-0"
                    id="sidebarToggle"
                >
                    <i className="fas fa-bars" />
                </button>{" "}
                &nbsp;&nbsp;
                <Link className="navbar-brand mr-1" to="/">
                    <img className="img-fluid" alt="" src="img/logo.png" />
                </Link>
                <form className="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-5 my-2 my-md-0 osahan-navbar-search">
                    <div className="input-group">
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Search for..."
                        />
                        <div className="input-group-append">
                            <button className="btn btn-light" type="button">
                                <i className="fas fa-search" />
                            </button>
                        </div>
                    </div>
                </form>
                <ul className="navbar-nav ml-auto ml-md-0 osahan-right-navbar">
                    <li className="nav-item mx-1">
                        <Link className="nav-link" to="/upload">
                            <i className="fas fa-plus-circle fa-fw" />
                            Upload Video
                        </Link>
                    </li>
                    <li className="nav-item dropdown no-arrow mx-1">
                        <Link
                            className="nav-link dropdown-toggle"
                            to="#"
                            id="alertsDropdown"
                            role="button"
                            data-toggle="dropdown"
                            aria-haspopup="true"
                            aria-expanded="false"
                        >
                            <i className="fas fa-bell fa-fw" />
                            <span className="badge badge-danger">9+</span>
                        </Link>
                        <div
                            className="dropdown-menu dropdown-menu-right"
                            aria-labelledby="alertsDropdown"
                        >
                            <Link className="dropdown-item" to="#">
                                <i className="fas fa-fw fa-edit " /> &nbsp; Action
                            </Link>
                            <Link className="dropdown-item" to="#">
                                <i className="fas fa-fw fa-headphones-alt " /> &nbsp; Another action
                            </Link>
                            <div className="dropdown-divider" />
                            <Link className="dropdown-item" to="#">
                                <i className="fas fa-fw fa-star " /> &nbsp; Something else here
                            </Link>
                        </div>
                    </li>
                    <li className="nav-item dropdown no-arrow mx-1">
                        <Link
                            className="nav-link dropdown-toggle"
                            to="#"
                            id="messagesDropdown"
                            role="button"
                            data-toggle="dropdown"
                            aria-haspopup="true"
                            aria-expanded="false"
                        >
                            <i className="fas fa-envelope fa-fw" />
                            <span className="badge badge-success">7</span>
                        </Link>
                        <div
                            className="dropdown-menu dropdown-menu-right"
                            aria-labelledby="messagesDropdown"
                        >
                            <Link className="dropdown-item" to="#">
                                <i className="fas fa-fw fa-edit " /> &nbsp; Action
                            </Link>
                            <Link className="dropdown-item" to="#">
                                <i className="fas fa-fw fa-headphones-alt " /> &nbsp; Another action
                            </Link>
                            <div className="dropdown-divider" />
                            <Link className="dropdown-item" to="#">
                                <i className="fas fa-fw fa-star " /> &nbsp; Something else here
                            </Link>
                        </div>
                    </li>
                    <li className="nav-item dropdown no-arrow osahan-right-navbar-user">
                        <Link
                            className="nav-link dropdown-toggle user-dropdown-link"
                            to="#"
                            id="userDropdown"
                            role="button"
                            data-toggle="dropdown"
                            aria-haspopup="true"
                            aria-expanded="false"
                        >
                            <img alt="Avatar" src="img/user.png" />
                            Osahan
                        </Link>
                        <div
                            className="dropdown-menu dropdown-menu-right"
                            aria-labelledby="userDropdown"
                        >
                            <Link className="dropdown-item" to="/myaccount"><i className="fas fa-fw fa-user-circle" /> &nbsp; My Account</Link>
                            {/* <Link className="dropdown-item" to="/subscriptions"><i className="fas fa-fw fa-video" /> &nbsp; Subscriptions</Link> */}
                            <Link className="dropdown-item" to="/setting"><i className="fas fa-fw fa-cog" /> &nbsp; Settings</Link>
                            <div className="dropdown-divider" />
                            <Link className="dropdown-item" to="" data-toggle="modal" data-target="#logoutModal"><i className="fas fa-fw fa-sign-out-alt" /> &nbsp; Logout</Link>
                        </div>
                    </li>
                </ul>
            </nav>



            <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <Link class="btn btn-primary" to="/login">Logout</Link>
                </div>
            </div>
        </div>
    </div>
        </>
    )
}

export default Header
